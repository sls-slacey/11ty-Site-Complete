const eleventySass = require("@11tyrocks/eleventy-plugin-sass-lightningcss");
const purgeCssPlugin = require("eleventy-plugin-purgecss");

module.exports = function (eleventyConfig) {
  eleventyConfig.addPlugin(eleventySass);

  // Add global data for current year
  eleventyConfig.addGlobalData("currentYear", new Date().getFullYear());

  // Copy Bootstrap JavaScript to public directory
  eleventyConfig.addPassthroughCopy({
    "node_modules/bootstrap/dist/js/bootstrap.bundle.min.js": "js/bootstrap.bundle.min.js"
  });

  // Copy Bootstrap Icons font files to public directory
  eleventyConfig.addPassthroughCopy({
    "node_modules/bootstrap-icons/font/fonts": "css/fonts"
  });

  // Copy images folder
  eleventyConfig.addPassthroughCopy("src/images");

  // Only run PurgeCSS in production to speed up development
  if (process.env.NODE_ENV === "production") {
    eleventyConfig.addPlugin(purgeCssPlugin, {
      config: "./purgecss.config.js",
      quiet: false,
    });
  }

  return {
    dir: {
      input: "src",
      output: "public",
    },
  };
};
